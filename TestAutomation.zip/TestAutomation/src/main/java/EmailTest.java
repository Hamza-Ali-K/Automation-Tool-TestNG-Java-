import org.testng.Assert;
import org.testng.annotations.Test;
public class EmailTest {
    // Positive Scenario
    @Test
    public void verifyWordPresent() {
        String emailContent =
                "Hello, welcome to the system. Thank you, rahat.";
        Assert.assertTrue(emailContent.contains("rahat"));
        System.out.println("Test Passed: Word 'rahat' found.");
    }
    // Negative Scenario
    @Test
    public void verifyWordAbsent() {
        String emailContent =
                "Hello, welcome to the system. Thank you, user.";
        Assert.assertFalse(emailContent.contains("rahat"));
        System.out.println("Test Passed: Word 'rahat' not found.");
    }
    // Positive Replacement Test
    @Test
    public void verifyWordReplacementSuccess() {
        String emailContent = "Hello user";
        String modifiedContent =
                emailContent.replace("user", "rahat");
        Assert.assertTrue(modifiedContent.contains("rahat"));
        Assert.assertFalse(modifiedContent.contains("user"));
        System.out.println("Test Passed: Word replaced successfully.");
    }
    // Negative Replacement Test
    @Test
    public void verifyWordReplacementFailure() {
        String emailContent = "Hello user";
        // No replacement performed
        String modifiedContent = emailContent;
        Assert.assertFalse(modifiedContent.contains("rahat"));
        Assert.assertTrue(modifiedContent.contains("user"));
        System.out.println("Test Passed: Replacement not performed.");
    }
}