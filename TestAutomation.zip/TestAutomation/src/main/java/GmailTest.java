import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
public class GmailTest {
    @Test
    public void openGmailAndEnterEmail() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://mail.google.com/");
        Thread.sleep(3000);
        driver.findElement(By.id("identifierId"))
                .sendKeys("test.user@example.com");
        Thread.sleep(5000);
        driver.quit();
    }
}
