import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;
import java.time.Duration;
public class LoginTest {
    WebDriver driver;
    WebDriverWait wait;
    @BeforeMethod
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://subexpert.com/Account/Login"); // replace with real URL
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    // =========================
    // POSITIVE TEST CASE
    // =========================
    @Test
    public void validLoginTest() {
        driver.findElement(By.id("UserName")).sendKeys("valid.user@example.com");
        driver.findElement(By.id("Password")).sendKeys("Test@12345");
        driver.findElement(By.id("LoginButton")).click();
        // validation after login
        String actualTitle = driver.getTitle();
        Assert.assertTrue(actualTitle.contains("Dashboard"), "Login failed!");
    }
    // =========================
    // INVALID USERNAME
    // =========================
    @Test
    public void invalidUsernameTest() {
        driver.findElement(By.id("UserName")).sendKeys("wrong.user@example.com");
        driver.findElement(By.id("Password")).sendKeys("Test@12345");
        driver.findElement(By.id("LoginButton")).click();
        String error = driver.findElement(By.id("errorMessage")).getText();
        Assert.assertEquals(error, "Invalid credentials");
    }
    // =========================
    // INVALID PASSWORD
    // =========================
    @Test
    public void invalidPasswordTest() {
        driver.findElement(By.id("UserName")).sendKeys("valid.user@example.com");
        driver.findElement(By.id("Password")).sendKeys("wrongpass");
        driver.findElement(By.id("LoginButton")).click();
        String error = driver.findElement(By.id("errorMessage")).getText();
        Assert.assertEquals(error, "Invalid credentials");
    }
    // =========================
    // EMPTY USERNAME
    // =========================
    @Test
    public void emptyUsernameTest() {
        driver.findElement(By.id("Password")).sendKeys("Test@12345");
        driver.findElement(By.id("LoginButton")).click();
        String msg = driver.findElement(By.id("validationMessage")).getText();
        Assert.assertEquals(msg, "Username is required");
    }
    // =========================
    // EMPTY PASSWORD
    // =========================
    @Test
    public void emptyPasswordTest() {
        driver.findElement(By.id("UserName")).sendKeys("valid.user@example.com");
        driver.findElement(By.id("LoginButton")).click();
        String msg = driver.findElement(By.id("validationMessage")).getText();
        Assert.assertEquals(msg, "Password is required");
    }
    // =========================
    // BOTH EMPTY
    // =========================
    @Test
    public void emptyFieldsTest() {
        driver.findElement(By.id("LoginButton")).click();
        String msg = driver.findElement(By.id("validationMessage")).getText();
        Assert.assertEquals(msg, "Fields cannot be empty");
    }
    // =========================
    // SPECIAL CHARACTERS
    // =========================
    @Test
    public void specialCharUsernameTest() {
        driver.findElement(By.id("UserName")).sendKeys("@@@###");
        driver.findElement(By.id("Password")).sendKeys("Test@12345");
        driver.findElement(By.id("LoginButton")).click();
        String error = driver.findElement(By.id("errorMessage")).getText();
        Assert.assertTrue(error.length() > 0);
    }
    // =========================
    // SQL INJECTION TEST
    // =========================
    @Test
    public void sqlInjectionTest() {
        driver.findElement(By.id("UserName")).sendKeys("' OR '1'='1");
        driver.findElement(By.id("Password")).sendKeys("any");
        driver.findElement(By.id("LoginButton")).click();
        String error = driver.findElement(By.id("errorMessage")).getText();
        Assert.assertEquals(error, "Invalid credentials");
    }
    @AfterMethod
    public void tearDown() throws InterruptedException {
        Thread.sleep(2000);
        driver.quit();
    }
}

